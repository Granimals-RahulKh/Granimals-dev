import os
import boto3
import json

cognito_idp = boto3.client('cognito-idp')

def lambda_handler(event, context):
    user_pool_id = os.environ.get('USER_POOL_ID')

    # Ensure body is parsed from API Gateway JSON payload
    try:
        body = json.loads(event.get('body', '{}'))
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid JSON in request body'})
        }

    username = body.get('username')
    new_password = body.get('new_password')

    if not user_pool_id or not username or not new_password:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing USER_POOL_ID, username, or new_password'})
        }

    try:
        cognito_idp.admin_set_user_password(
            UserPoolId=user_pool_id,
            Username=username,
            Password=new_password,
            Permanent=True
        )
        print(f"✅ Password updated for user {username}")
        return {
            'statusCode': 200,
            'body': json.dumps({'message': f"Password for user '{username}' changed successfully"})
        }

    except Exception as e:
        print(f"❌ Error changing password: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }