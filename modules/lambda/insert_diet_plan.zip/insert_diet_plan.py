import boto3
import json
import os
import psycopg2
import traceback

# def get_db_credentials(secret_arn):
#     client = boto3.client('secretsmanager')
#     response = client.get_secret_value(SecretId=secret_arn)
#     secret = json.loads(response['SecretString'])
#     return secret

def lambda_handler(event, context):
    try:
        print("Parsing request body...")
        body = json.loads(event.get('body', '{}'))
        print("Parsed body:", body)

        creds = {
            "host": "granimals-dev-cluster-1.cr82g6co4rta.ap-south-1.rds.amazonaws.com",
            "port": 5432,
            "dbname": "granimalsdev",
            "username": "granimals_rds",
            "password": "rdsSecret#1"
        }

        print("Connecting to DB...")
        conn = psycopg2.connect(
            host=creds['host'],
            port=creds['port'],
            dbname=creds['dbname'],
            user=creds['username'],
            password=creds['password']
        )
        cursor = conn.cursor()
        print("Connected to DB")

        if 'diet_plan_id' in body:
            print("Starting insert for diet_plan:", body['diet_plan_id'])
            insert_diet_plan(cursor, body)
        else:
            print("No diet_plan_id found in the body")

        conn.commit()
        print("Transaction committed")

        cursor.close()
        conn.close()
        print("Connection closed")

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Data inserted successfully"})
        }

    except Exception as e:
        print("Exception occurred:", str(e))
        traceback.print_exc()
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }


def insert_diet_plan(cursor, data):
    print("Inserting into diet_plans...")
    cursor.execute("""
        INSERT INTO diet_plans (diet_plan_id, category, support_staff_id)
        VALUES (%s, %s, %s)
    """, (data['diet_plan_id'], data['category'], data['support_staff_id']))

    for week in data.get('weeks', []):
        print("Processing week:", week['diet_week_id'])
        insert_diet_week(cursor, data['diet_plan_id'], week)


def insert_diet_week(cursor, diet_plan_id, week):
    print("Inserting into diet_weeks...")
    cursor.execute("""
        INSERT INTO diet_weeks (diet_week_id, diet_plan_id, week_number)
        VALUES (%s, %s, %s)
    """, (week['diet_week_id'], diet_plan_id, week['week_number']))

    for day in week.get('days', []):
        print("Processing day:", day['diet_day_id'])
        insert_diet_day(cursor, week['diet_week_id'], day)


def insert_diet_day(cursor, diet_week_id, day):
    print("Inserting into diet_days...")
    cursor.execute("""
        INSERT INTO diet_days (diet_day_id, diet_week_id, diet_day_name, date_assigned)
        VALUES (%s, %s, %s, %s)
    """, (day['diet_day_id'], diet_week_id, day['diet_day_name'], day['date_assigned']))

    for meal in day.get('meals', []):
        print("Processing meal:", meal.get('meal_id'))
        insert_diet_meal(cursor, day['diet_day_id'], meal)


def insert_diet_meal(cursor, diet_day_id, meal):
    print("Inserting into diet_meals...")
    cursor.execute("""
        INSERT INTO diet_meals (
            diet_day_id, meal_type, meal_id, meal_name,
            calories, proteins, fibers, fats,
            time_of_meal, status, notes
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        diet_day_id,
        meal.get('meal_type'),
        meal.get('meal_id'),
        meal.get('meal_name'),
        meal.get('calories'),
        meal.get('proteins'),
        meal.get('Fibers') or meal.get('fibers'),
        meal.get('fats'),
        meal.get('time_of_meal'),
        meal.get('status'),
        json.dumps(meal.get('notes', []))
    ))
