import os
import json
import boto3
from botocore.exceptions import ClientError

cognito_idp = boto3.client('cognito-idp', region_name='ap-south-1')  # Change region if needed

def lambda_handler(event, context):
    user_pool_id = os.environ.get('USER_POOL_ID')
    client_id = os.environ.get('USER_POOL_CLIENT_ID')

    # Parse JSON body if coming from API Gateway
    if isinstance(event, dict) and "body" in event:
        try:
            event = json.loads(event["body"])
        except Exception:
            return {
                'statusCode': 400,
                'body': json.dumps({"message": "Invalid JSON in request body"})
            }

    username = event.get('username')
    password = event.get('password')

    if not user_pool_id or not client_id or not username or not password:
        return {
            'statusCode': 400,
            'body': json.dumps({"message": 'Missing "username" or "password" in the request'})
        }

    # Step 1: Check if user exists
    try:
        cognito_idp.admin_get_user(
            UserPoolId=user_pool_id,
            Username=username
        )
    except cognito_idp.exceptions.UserNotFoundException:
        return {
            'statusCode': 404,
            'body': json.dumps({"message": "User not found. Please register to continue."})
        }
    except ClientError as e:
        print(f"❌ Error checking user: {e.response['Error']['Message']}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                "message": f"Internal error checking user existence: {e.response['Error']['Message']}"
            })
        }

    # Step 2: Try authenticating user
    try:
        auth_response = cognito_idp.initiate_auth(
            ClientId=client_id,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': password
            }
        )

        # Step 3: Get group membership
        group_response = cognito_idp.admin_list_groups_for_user(
            UserPoolId=user_pool_id,
            Username=username
        )

        groups = group_response.get("Groups", [])
        group_name = groups[0]["GroupName"] if groups else "user"  # Default to "user" if no group

        return {
            'statusCode': 200,
            'body': json.dumps({
                "message": f"Success.you are logged in as '{group_name}'.",
                "group": f"You are logged in as '{group_name}'."
            })
        }

    except cognito_idp.exceptions.NotAuthorizedException:
        return {
            'statusCode': 401,
            'body': json.dumps({"message": "Incorrect username or password. Please try again."})
        }

    except cognito_idp.exceptions.UserNotConfirmedException:
        return {
            'statusCode': 403,
            'body': json.dumps({"message": "User not confirmed. Please verify your email before logging in."})
        }

    except ClientError as e:
        print(f"❌ Login error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({"message": "An unexpected error occurred during login."})
        }
